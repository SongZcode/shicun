// a_bogus + secsdk stub
export function signQuery(){ return ''; }
